#include <stdio.h>
#include <stdlib.h>

int isLittleEndian()
{
    union a{
        int i;
        char x;
    }u;
    u.i=1;
    if(u.x==1){
        return 1;
    }
    else return 0;
}
int main()
{
    int result = isLittleEndian();
    if(result){
        printf("С��\n");
    }
    else printf("���\n");
    return 0;
}
