#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char *byte_pointer;

void show_bytes(byte_pointer start,size_t len)
{
    size_t i;
    for(i=0;i<len;i++){
        printf("%.2x",start[i]);
    }
    printf("\n");
}
void show_int(int x)
{
    show_bytes((byte_pointer)&x,sizeof(int));
}
void show_float(float x)
{
    show_bytes((byte_pointer)&x,sizeof(float));
}
void show_pointer(void *x)
{
    show_bytes((byte_pointer)&x,sizeof(void*));
}
void show_char(char x)
{
    show_bytes((byte_pointer)&x,sizeof(char));
}
void show_double(double x)
{
    show_bytes((byte_pointer)&x,sizeof(double));
}
//enum spring{Jan,Feb,Mar}month;
//month = Mar;

/*void show_enum(spring x)
{
    show_bytes((byte_pointer)&x,sizeof(spring));
}*/
/*void show_flag( x)
{
    show_bytes((byte_pointer)&x,sizeof(bool));
}*/


int main()
{
    int a = 1190202210;
    short a2 = 2210;
    long a3 = 1190202210;
    char b = 'c';
    float c = 3.14159;
    double d = 3.1415926;
    //bool e = false;
    int *f = &a;
    char *g;
    //g=b;
    float *h = &c;
    const char *s = "chenyang";

    double *i = &d;
    int data[5]={0,1,2,3,4};
    struct person{
        int id;
        int age;

    }cy;
    cy.id=2210;
    cy.age=20;
    union chenyang{
        int j;
        char x;
    }u;
    u.j=1;
    enum spring{Jan,Feb,Mar}month;
    month = Mar;


    printf("��������\t������\t\t����ֵ\t\t\t������ַ\t\t16�����ڴ�ĸ��ֽ�\n");
    printf("int\t\ta\t\t%d\t\t%p\t\t",a,&a);
    show_int(a);

    printf("short\t\ta2\t\t%d\t\t\t%p\t\t",a2,&a2);
    show_bytes((byte_pointer)&a2,sizeof(short));

    printf("long\t\ta3\t\t%ld\t\t%p\t\t",a3,&a3);
    show_bytes((byte_pointer)&a3,sizeof(long));

    printf("char\t\tb\t\t%c\t\t\t%p\t\t",b,&b);
    show_char(b);
    printf("char\t\ts\t\tchenyang\t\t%p\t\t",*s,s);
    show_bytes((byte_pointer)s,strlen(s));
    printf("float\t\tc\t\t%f\t\t%p\t\t",c,&c);
    show_float(c);
    printf("double\t\td\t\t%lf\t\t%p\t\t",d,&d);
    show_double(d);
    printf("int*\t\tf\t\t%p\t\t%p\t\t",f,&f);
    show_pointer(f);

    printf("����\t\tdata[0]\t\t%d\t\t\t%p\t\t",data[0],&data[0]);
    show_int(data[0]);
    printf("����\t\tdata[1]\t\t%d\t\t\t%p\t\t",data[1],&data[1]);
    show_int(data[1]);
    printf("struct\t\tcy.age\t\t%d\t\t\t%p\t\t",cy.age,&cy.age);
    show_int(cy.age);
    printf("union\t\tu.j\t\t%d\t\t\t%p\t\t",u.j,&u.j);
    show_int(u.j);
    printf("enum\t\tmonth\t\t%d\t\t\t%p\t\t",month,&month);
    show_int(month);


    printf("\n");
    printf("printf �ĵ�ַ\t%p\n",&printf);
    printf("main �ĵ�ַ\t%p\n",&main);
    return 0;
}
